package edu.neu.cs6650.project2.MyClient;

public class TaskResult {
	public long startTime;
	public long endTime;
	public long latency;
	public boolean success;
	public String requestType;
	public String content;
}
